package com.example.projekt2;

        import androidx.annotation.RequiresApi;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.core.app.NotificationCompat;
        import androidx.core.app.NotificationManagerCompat;

        import android.annotation.SuppressLint;
        import android.app.Notification;
        import android.app.NotificationChannel;
        import android.app.NotificationManager;
        import android.app.PendingIntent;
        import android.content.Context;
        import android.content.Intent;
        import android.os.Build;
        import android.os.Bundle;
        import android.view.Gravity;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.RemoteViews;
        import android.widget.TextView;
        import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int clickCounter = 0;
    private Notification.Builder builder; //added
    private NotificationManager mNotifyMgr;
    private RemoteViews remoteViews; //added
    private Context context; //added

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this; //added
        mNotifyMgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE); //added
        remoteViews = new RemoteViews(getPackageName(), R.layout.custom_notification); //added

    }
    private void showNotification(Notification.Builder builder){
        //mNotifyMgr.notify(clickCounter /*0*/, builder.build());
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private Notification.Builder getBuilder(String title, String text){
        return new Notification.Builder(this, "channel_ID").setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(text);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void showBasicNotification(View view){  //first button
        showNotification(getBuilder("basic notification", totalClicks()));
    }

    @SuppressLint("NewApi")
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void showCustomNotification(View view){ //second button
        String title =  "custom notification";
        String text = totalClicks();

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("My Notification1", "My Notification", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        RemoteViews remoteViews = new RemoteViews(getPackageName(), R.layout.custom_notification );

        remoteViews.setTextViewText(R.id.ntitle, title);
        remoteViews.setTextViewText(R.id.ntext, text);//2nd txt
        remoteViews.setImageViewResource(R.id.imageleft, R.mipmap.ic_launcher);
        remoteViews.setImageViewResource(R.id.imageright, R.mipmap.ic_launcher);//2nd img

        NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, "My Notification1");
        builder.setCustomContentView(remoteViews);
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setAutoCancel(true);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivity.this);
        managerCompat.notify(1, builder.build());


    }
    public void showBasic(View view){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("My Notification1", "My Notification", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, "My Notification1");
        builder.setContentTitle("Basic Notification");
        builder.setContentText(""+totalClicks());
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setAutoCancel(true);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivity.this);
        managerCompat.notify(1, builder.build());
    }
    public void showBasicToast(View view){
        Toast.makeText(context, ""+totalClicks(), Toast.LENGTH_SHORT).show();
    }
    public void showCustomToast(View view){
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.toast_layout, (ViewGroup) findViewById(R.id.toast_root));

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER, 0,0);
        TextView text = layout.findViewById(R.id.toast_txt);

        text.setText(""+totalClicks());

        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }

    private String totalClicks(){
        return "Total clicks so far: " + ++clickCounter;

    }
}